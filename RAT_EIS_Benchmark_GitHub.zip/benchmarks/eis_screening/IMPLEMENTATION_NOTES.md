# Findings in the supplied source; no numerical edits applied

## 1. A morphology category takes precedence over fitting evidence

Source: `source_snapshots/eis_auto.py`, function `circuit_selection_key` (starting at line 1270).

The key is lexicographic: fit status; hard rejection; physical-status category; bound-hit indicator/count; identifiability rank; residual-structure rank; adjusted BIC; adjusted AICc; numerical errors and later tie-breakers. Consequently, a `consistent` candidate always beats a `plausible` candidate before its residual error or information criterion is considered.

Source: `source_snapshots/eis_physics.py`, `analyze_eis_physics` (lines around 262–266) and `physics_compatibility` (starting at line 424).

The apparent-loop count starts from the smoothed Bode-phase peak count. In the controlled factor-100 example, the analysis records two Nyquist peaks at 10 and 1000 Hz but one phase peak; `apparent_loops` remains one. The two-RQ candidate receives a loop-mismatch penalty and `plausible` status. This is an advisory morphology estimate, not a reason to prefer a 13.604% MRE fit over an essentially exact fit.

Concrete native result: `native_outputs/overlap_ratio100_00_r0/case_result.json`.

| Candidate | Final rank | MRE (%) | Morphology status | Bound hits | Identifiability | Adjusted BIC | Adjusted AICc |
| --- | --- | --- | --- | --- | --- | --- | --- |
| R0-p(R1,CPE1) | 1 | 13.6043503 | consistent | 0 | good | -705.6886 | -717.7842 |
| R0-p(R1,CPE1)-p(R2,CPE2) | 3 | 5.3482e-10 | plausible | 0 | good | -4422.6122 | -4443.4981 |

The true circuit is present and fitted; this example isolates ranking behavior from library omission or fitting failure.

## 2. The confidence summary and final selection use different orderings

Source: `source_snapshots/eis_physics.py`, `annotate_model_confidence` (starting at line 707), and `source_snapshots/eis_auto.py`, `_run_pipeline_worker` (starting at line 4083).

The confidence summary sorts eligible candidates solely by `physics_adjusted_aicc`, whereas final selection uses the lexicographic key described above. The GUI then displays the global confidence status next to the final selection. The leading circuits differ in 36/89 tested cases. In the factor-100 example, the fitted true two-RQ candidate has adjusted-AICc weight 1.0, while the selected single-RQ candidate has approximately 9.86e-305. The displayed global summary is nevertheless `preferred`.

This finding does not mean adjusted-AICc weights are calibrated probabilities of correct physical models. They compare eligible candidates under the implemented scoring assumptions and heuristic penalties. They cannot establish that the generating topology is included in the candidate library.

## 3. Outside-library identification is not implemented by confidence scoring

At the tested level and with learned suggestions disabled, `build_physics_guided_candidates` constructs no Gerischer G model. The token parser recognizing the letter G does not add such a candidate. All seven G-generating inputs return a single-RQ surrogate, and five receive a `preferred` library-confidence label. This is expected to be possible for relative model comparison; it must not be described as detection or recovery of an absent mechanism.

## 4. Runtime-specific Lin-KK failure

All native Lin-KK diagnostics in the recorded NumPy 2.3.5 / impedance.py 1.7.1 environment return `name 'np' is not defined`. The package builds and evaluates strings containing NumPy scalar representations. This issue does not feed the native candidate selection in this worker and was not patched for the benchmark. The raw failure state is preserved. Avoid reporting a Lin-KK pass rate from these runs.

