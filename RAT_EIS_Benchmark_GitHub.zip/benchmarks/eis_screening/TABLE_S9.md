# Table S9. Summary of the additional automated EIS screening tests

| Test group | Conditions | Number of spectra | Outcome |
| --- | --- | ---: | --- |
| Added noise | Three circuits; eta = 0, 3, 5, 10 and 20% | 39 | Exact recovery: single RQ, 7/13; two RQ, 0/13; RQ + W, 4/13 |
| Controlled relaxation separation | Two RQ; frequency ratios 100, 10, 3 and 1.3; eta = 0 and 3% | 16 | Generating topology selected first in 0/16 cases |
| Restricted frequency windows | Three circuits; three retained windows; eta = 3% | 27 | Exact recovery: single RQ, 5/9; two RQ, 0/9; RQ + W, 2/9 |
| Generating topology outside the library | RQ + Gerischer; eta = 0, 3 and 10% | 7 | Generating topology absent; single-RQ surrogate returned in all seven cases; MRE = 2.602–12.748% |

RQ denotes a resistor parallel to a CPE. Exact recovery means selection of the generating topology as the first-ranked candidate. Outside-library recovery is not applicable because the generating topology is absent. Counts are controlled scenario outcomes, not estimates of general experimental identification accuracy. The complete condition-level counts, native outputs and implementation limitations are provided in this directory.
