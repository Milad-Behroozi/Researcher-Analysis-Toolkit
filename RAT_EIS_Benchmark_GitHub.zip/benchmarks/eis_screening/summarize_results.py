"""Summarize every predeclared case; keep unsuccessful recoveries in counts."""
from pathlib import Path
import csv
import json
from collections import Counter
import numpy as np

ROOT = Path(__file__).resolve().parent
MODELS = ['single_rq', 'double_rq', 'rq_w']


def summarize(rows):
    selected = [r['selected_result'] for r in rows if r['selected_result'] is not None]
    errors = [100*r['mean_rel_err'] for r in selected]
    supported = [r for r in rows if r['family'] != 'out_of_library']
    return {
        'n': len(rows),
        'generating_circuit_present': sum(r['generating_circuit_present'] for r in rows),
        'exact_topology_recovered': (sum(r['exact_topology_recovered'] for r in rows)
                                     if supported else None),
        'pipeline_errors': sum(bool(r['errors']) for r in rows),
        'selected_MRE_percent_range': [min(errors), max(errors)] if errors else None,
        'selected_bound_hits_cases': sum(r['bound_hits'] > 0 for r in selected),
        'selected_identifiability_flagged': sum(r['identifiability_rank'] > 0 for r in selected),
        'selected_structured_residual_cases': sum(r['residual_structure_rank'] > 0 for r in selected),
        'confidence_status_counts': dict(Counter(r['confidence_summary'].get('selection_status') for r in rows)),
        'selected_differs_from_AICc_leader': sum(r['selected_circuit'] != r['physics_adjusted_AICc_leader'] for r in rows),
        'selected_circuit_counts': dict(Counter(r['selected_circuit'] for r in rows)),
    }


def count_cell(rows):
    return f"{sum(r['exact_topology_recovered'] for r in rows)}/{len(rows)}"


def make_tables(results):
    lines = ['# Table S9. Controlled tests of the native automatic EIS screening workflow', '']
    lines += ['Values in panels (a–c) are the number of cases in which the generating topology was selected first, divided by the number tested. A generating topology excluded from the data-dependent candidate list is counted as no recovery. RQ denotes R parallel to CPE. These are end-to-end selection results, not fixed-circuit fitting accuracy.', '',
              '## (a) Added Gaussian noise', '',
              '| Noise coefficient, eta (%) | Single RQ | Two RQ | RQ + W |',
              '| --- | --- | --- | --- |']
    for eta in [0., .03, .05, .10, .20]:
        cells = [count_cell([r for r in results if r['family']=='noise' and r['model']==m and r['noise_fraction']==eta]) for m in MODELS]
        lines.append(f"| {eta*100:g} | " + ' | '.join(cells) + ' |')
    lines += ['', 'Noise is the standard deviation of each real/imaginary perturbation, scaled by the noise-free impedance modulus; it is not the resulting complex MRE. Full spectra contain 50 points from 0.01 to 10^6 Hz. The two-RQ coefficients here are those in Table S1 and give strongly overlapping individual characteristic frequencies (approximately 539 and 707 Hz).', '',
              '## (b) Controlled overlap of two RQ relaxations', '',
              '| Characteristic-frequency ratio, f1/f2 | No added noise | eta = 3% |',
              '| --- | --- | --- |']
    for ratio in [100.,10.,3.,1.3]:
        cells=[count_cell([r for r in results if r['family']=='overlap' and r['true_peak_frequency_ratio']==ratio and r['noise_fraction']==eta]) for eta in [0.,.03]]
        lines.append(f"| {ratio:g} | "+' | '.join(cells)+' |')
    lines += ['', 'Here R0 = 10 ohm, R1 = R2 = 100 ohm and n1 = n2 = 0.85; f1 = 1000 Hz and Qj = 1/[Rj(2*pi*fj)^nj]. Each spectrum contains 81 logarithmic frequency points from 0.01 to 10^6 Hz.', '',
              '## (c) Frequency-window restriction at eta = 3%', '',
              '| Frequency-window rule | Single RQ | Two RQ | RQ + W |',
              '| --- | --- | --- | --- |']
    windows=[('full','Full: 0.01–10^6 Hz'),('without_low','Retain f >= 1 Hz'),('without_high','Retain f <= 1000 Hz'),('central_window','Retain 1 <= f <= 1000 Hz')]
    for window,label in windows:
        if window=='full':
            groups=[[r for r in results if r['family']=='noise' and r['noise_fraction']==.03 and r['model']==m] for m in MODELS]
        else:
            groups=[[r for r in results if r['family']=='truncation' and r['window']==window and r['model']==m] for m in MODELS]
        lines.append('| '+label+' | '+' | '.join(count_cell(g) for g in groups)+' |')
    lines += ['', 'Truncations retain exactly the corresponding original noisy data points; no interpolation, resampling or new noise is introduced. The retained point count and actual endpoint frequencies for every case are supplied in case_summary.csv.', '',
              '## (d) Generating topology outside the candidate library', '',
              '| eta (%) | Cases | Generating topology admitted | Selected MRE range (%) | Cases with structured residuals | Native confidence-summary labels |',
              '| --- | --- | --- | --- | --- | --- |']
    for eta in [0.,.03,.10]:
        group=[r for r in results if r['family']=='out_of_library' and r['noise_fraction']==eta]
        s=summarize(group)
        er=s['selected_MRE_percent_range']
        mre=f'{er[0]:.3f}' if len(group)==1 else f'{er[0]:.3f}–{er[1]:.3f}'
        labels=', '.join(f'{k}: {v}' for k,v in s['confidence_status_counts'].items())
        lines.append(f"| {eta*100:g} | {len(group)} | {s['generating_circuit_present']}/{len(group)} | {mre} | {s['selected_structured_residual_cases']}/{len(group)} | {labels} |")
    lines += ['', 'The generating circuit is R0-p(R1,CPE1)-G1, with the single-RQ coefficients from Table S1 and ZG = RG/sqrt(1+j*2*pi*f*tG), RG = 30 ohm and tG = 0.01 s. No G-containing candidate is constructed at the tested search level. Topology recovery is therefore not applicable for this panel. A structured-residual case has the native residual_structure_rank > 0 (absolute lag-one residual correlation >= 0.35). The confidence summary compares eligible library candidates by adjusted AICc; it does not test library completeness. Its leading candidate can differ from the final lexicographically ranked selection.', '',
              'All 89 cases were generated outside RAT using analytical NumPy equations and tested through the supplied, unmodified RAT 1.3.0-physics-preview automatic worker (physics engine 2.0.0), search level L3, default native seed 20260821 and auto-learning disabled. Three fixed noise realizations were used at each nonzero noise level. The same deviates were scaled across noise levels within each model/repeat. Optional Level 5/AutoEIS was not evaluated. All cases and candidate results, including failures to recover the generating circuit, are retained.', '']
    return '\n'.join(lines)


def make_plot(results, cases):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    from matplotlib.cm import ScalarMappable
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titlesize':11,
                         'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'ps.fonttype':42})
    fig,axes=plt.subplots(2,2,figsize=(10.8,7.4),layout='constrained')
    cmap=plt.get_cmap('Blues'); norm=Normalize(0,1)
    def heat(ax,groups,xlabels,ylabels,title):
        arr=np.array([[sum(r['exact_topology_recovered'] for r in g)/len(g) for g in row] for row in groups])
        ax.imshow(arr,cmap=cmap,norm=norm,aspect='auto')
        ax.set_xticks(range(len(xlabels)),xlabels)
        ax.set_yticks(range(len(ylabels)),ylabels)
        ax.set_title(title,loc='left',fontweight='bold',pad=10)
        for i,row in enumerate(groups):
            for j,g in enumerate(row):
                ax.text(j,i,count_cell(g),ha='center',va='center',color='white' if arr[i,j]>.60 else '#142c40',fontsize=12)
        for spine in ax.spines.values():spine.set_visible(False)
    g1=[[[r for r in results if r['family']=='noise' and r['model']==m and r['noise_fraction']==eta] for eta in [0.,.03,.05,.10,.20]] for m in MODELS]
    heat(axes[0,0],g1,['0','3','5','10','20'],['Single RQ','Two RQ','RQ + W'],'(a) Added noise')
    axes[0,0].set_xlabel('Noise coefficient, eta (%)')
    g2=[[[r for r in results if r['family']=='overlap' and r['noise_fraction']==eta and r['true_peak_frequency_ratio']==ratio] for ratio in [100.,10.,3.,1.3]] for eta in [0.,.03]]
    heat(axes[0,1],g2,['100','10','3','1.3'],['No noise','3% noise'],'(b) Two-RQ separation')
    axes[0,1].set_xlabel('Generating characteristic-frequency ratio')
    g3=[]
    for m in MODELS:
        row=[[r for r in results if r['family']=='noise' and r['noise_fraction']==.03 and r['model']==m]]
        row += [[r for r in results if r['family']=='truncation' and r['model']==m and r['window']==w] for w in ['without_low','without_high','central_window']]
        g3.append(row)
    heat(axes[1,0],g3,['Full','f ≥ 1 Hz','f ≤ 1 kHz','1 Hz–1 kHz'],['Single RQ','Two RQ','RQ + W'],'(c) Frequency restriction at 3% noise')
    axes[1,0].tick_params(axis='x',labelsize=9)
    fig.colorbar(ScalarMappable(norm=norm,cmap=cmap),ax=[axes[0,0],axes[0,1],axes[1,0]],shrink=.62,pad=.02,label='Generating topology selected first (fraction)')
    example=next(r for r in results if r['id']=='out_of_library_G_00_r0')
    case=cases[example['id']]
    f=np.array(case['frequency_Hz']);z=np.array(case['Z_real_ohm'])+1j*np.array(case['Z_imag_ohm'])
    selected=example['selected_result']
    zfit=np.array(selected['fit_real_ohm'])+1j*np.array(selected['fit_imag_ohm'])
    axes[1,1].semilogx(f,100*abs(z-zfit)/abs(z),'-o',color='#bc4b27',markersize=3,linewidth=1.2)
    axes[1,1].set(xlabel='Frequency (Hz)',ylabel='Relative residual magnitude (%)')
    axes[1,1].set_title('(d) Outside-library case, no added noise',loc='left',fontweight='bold',pad=10)
    axes[1,1].set_ylim(0,6.3)
    axes[1,1].text(.97,.97,f"Selected MRE = {100*selected['mean_rel_err']:.2f}%\nLibrary confidence label: {example['confidence_summary']['selection_status']}",transform=axes[1,1].transAxes,va='top',ha='right',fontsize=9,bbox={'facecolor':'white','edgecolor':'#dddddd','alpha':.95})
    axes[1,1].grid(alpha=.17)
    fig.savefig(ROOT/'Figure_S12.png',dpi=300,bbox_inches='tight')
    fig.savefig(ROOT/'Figure_S12.pdf',bbox_inches='tight')
    plt.close(fig)

    example=next(r for r in results if r['id']=='overlap_ratio100_00_r0')
    case=cases[example['id']]
    f=np.array(case['frequency_Hz']);z=np.array(case['Z_real_ohm'])+1j*np.array(case['Z_imag_ohm'])
    selected=example['selected_result']
    truth=next(r for r in example['ranked_results'] if r['circuit']==example['generating_circuit'])
    zs=np.array(selected['fit_real_ohm'])+1j*np.array(selected['fit_imag_ohm'])
    zt=np.array(truth['fit_real_ohm'])+1j*np.array(truth['fit_imag_ohm'])
    fig,axes=plt.subplots(1,2,figsize=(10,4.1),layout='constrained')
    axes[0].plot(z.real,-z.imag,'o',markersize=4,markerfacecolor='none',color='#333333',label='Independent noise-free input')
    axes[0].plot(zt.real,-zt.imag,'-',color='#1f779b',linewidth=2,label='Fitted two-RQ candidate (rank 3)')
    axes[0].plot(zs.real,-zs.imag,'--',color='#bc4b27',linewidth=2,label='Selected single-RQ candidate (rank 1)')
    axes[0].set(xlabel="Z real (ohm)",ylabel="-Z imaginary (ohm)")
    axes[0].set_title('(a) Two separated relaxations, no added noise',loc='left',fontweight='bold')
    axes[0].legend(fontsize=8,loc='upper right')
    axes[0].set_ylim(-2,95)
    axes[1].semilogx(f,100*abs(z-zs)/abs(z),'-',color='#bc4b27',label=f"Selected single RQ: MRE {100*selected['mean_rel_err']:.3f}%")
    axes[1].semilogx(f,100*abs(z-zt)/abs(z),'-',color='#1f779b',label=f"Two RQ: MRE {100*truth['mean_rel_err']:.2e}%")
    axes[1].set(xlabel='Frequency (Hz)',ylabel='Relative residual magnitude (%)')
    axes[1].set_ylim(-1,27)
    axes[1].set_title('(b) Better fit is available within the library',loc='left',fontweight='bold')
    axes[1].legend(fontsize=8,loc='upper right')
    for ax in axes:ax.grid(alpha=.16)
    fig.savefig(ROOT/'Ranking_Diagnostic.png',dpi=220,bbox_inches='tight')
    fig.savefig(ROOT/'Ranking_Diagnostic.pdf',bbox_inches='tight')
    plt.close(fig)


def main():
    cases=json.loads((ROOT/'input_cases.json').read_text())
    results=[]
    for c in cases:
        p=ROOT/'native_outputs'/c['id']/'case_result.json'
        if not p.exists():raise RuntimeError('Suite incomplete: '+c['id'])
        results.append(json.loads(p.read_text()))
    assert len(results)==89 and len({r['id'] for r in results})==89
    family={f:summarize([r for r in results if r['family']==f]) for f in ['noise','overlap','truncation','out_of_library']}
    summary={'families':family,'total_pipeline_errors':sum(bool(r['errors']) for r in results),
             'total_confidence_rank_mismatch':sum(r['selected_circuit']!=r['physics_adjusted_AICc_leader'] for r in results),
             'LinKK_status_counts':dict(Counter(r['lin_kk'].get('status') for r in results))}
    (ROOT/'summary_results.json').write_text(json.dumps(summary,indent=2)+'\n')
    with (ROOT/'case_summary.csv').open('w',newline='') as out:
        columns=['id','family','model','noise_fraction','repeat','N','frequency_min_Hz','frequency_max_Hz',
                 'true_peak_frequency_ratio','window','candidate_count','generating_circuit_present',
                 'generating_circuit_rank','generating_circuit_fit_status','exact_topology_recovered',
                 'selected_circuit','MRE_percent','RMSE_ohm','selected_bound_hits','identifiability_status',
                 'identifiability_flags','physical_status','physical_reasons','residual_lag1_absmax',
                 'residual_structure_rank','confidence_summary_status','AICc_leading_circuit',
                 'selected_matches_AICc_leader','selected_Akaike_weight','selected_delta_AICc',
                 'LinKK_status','LinKK_message','pipeline_errors']
        writer=csv.DictWriter(out,fieldnames=columns);writer.writeheader()
        for r in results:
            s=r['selected_result'] or {}
            row={k:r.get(k) for k in columns if k in r}
            row.update(frequency_min_Hz=r['frequency_range_Hz'][0],frequency_max_Hz=r['frequency_range_Hz'][1],
                       MRE_percent=100*s.get('mean_rel_err',np.nan),RMSE_ohm=s.get('rmse_abs'),
                       selected_bound_hits=s.get('bound_hits'),identifiability_status=s.get('identifiability_status'),
                       identifiability_flags='; '.join(s.get('identifiability_flags',[])),
                       physical_status=s.get('physical_status'),physical_reasons='; '.join(s.get('physical_reasons',[])),
                       residual_lag1_absmax=s.get('residual_structure'),residual_structure_rank=s.get('residual_structure_rank'),
                       confidence_summary_status=r['confidence_summary'].get('selection_status'),
                       AICc_leading_circuit=r['physics_adjusted_AICc_leader'],
                       selected_matches_AICc_leader=r['selected_circuit']==r['physics_adjusted_AICc_leader'],
                       selected_Akaike_weight=s.get('akaike_weight'),selected_delta_AICc=s.get('delta_aicc_physics'),
                       LinKK_status=r['lin_kk'].get('status'),LinKK_message=r['lin_kk'].get('message'),
                       pipeline_errors=json.dumps(r['errors']))
            writer.writerow(row)
    (ROOT/'TABLE_S9.md').write_text(make_tables(results))
    make_plot(results,{c['id']:c for c in cases})
    print(json.dumps(summary,indent=2))


if __name__=='__main__':main()
