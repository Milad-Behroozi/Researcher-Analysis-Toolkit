"""Check analytical impedance conventions, without using a package to generate data."""
from pathlib import Path
import argparse
import json
import sys
import numpy as np

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--dependency-path')
args=parser.parse_args()
if args.dependency_path:sys.path.insert(0,args.dependency_path)
from impedance.models.circuits import CustomCircuit

root=Path(__file__).resolve().parent
cases=json.loads((root/'input_cases.json').read_text())
checks=[]
for name in ['single_rq','double_rq','rq_w','rq_g']:
    c=next(c for c in cases if c['model']==name and c['noise_fraction']==0)
    p=c['true_parameters']
    coeff=[p['R0'],p['R1'],p['Q1'],p['n1']]
    if name=='double_rq':coeff += [p['R2'],p['Q2'],p['n2']]
    elif name=='rq_w':coeff += [p['AW']]
    elif name=='rq_g':coeff += [p['RG'],p['tG']]
    ref=CustomCircuit(c['generating_circuit'],initial_guess=coeff).predict(np.array(c['frequency_Hz']),use_initial=True)
    clean=np.array(c['Z_clean_real_ohm'])+1j*np.array(c['Z_clean_imag_ohm'])
    delta=float(np.max(abs(ref-clean)/abs(clean)))
    assert delta<1e-12,(name,delta)
    checks.append({'model':name,'max_relative_evaluator_difference':delta})
(root/'generator_equation_checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks))
