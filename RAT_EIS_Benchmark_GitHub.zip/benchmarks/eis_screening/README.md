# Automated EIS screening benchmark

This directory contains the inputs, source snapshot, scripts and complete outputs for the additional 89-spectrum EIS screening assessment accompanying Table S9 and Figure S12. All predeclared cases are retained, including unsuccessful generating-topology recovery and failed candidate fits.

## Tested implementation and conditions

- Automatic EIS module: **1.3.0-physics-preview**.
- Physics engine: **2.0.0**.
- Native main GUI worker executed without numerical source changes; display callbacks replaced for batch execution.
- Search level **L3**; allowed element families R, C, CPE, W and L.
- Auto-learning **disabled** through the native configuration mechanism.
- Default base seed for fitting refinement: **20260821**. The native refinement stream also depends on the circuit string.
- Optional Level 5 / AutoEIS and the legacy search route were not evaluated.

Input spectra were generated outside RAT from analytical NumPy circuit equations. The CPE, semi-infinite Warburg and Gerischer conventions were checked against the impedance.py evaluator, which was not used to generate the spectra. Per-case noise seeds and all generating coefficients are recorded in `input_cases.json`. The generation seed base is 20261019, with model/family/repeat offsets specified in `generate_cases.py`; this is separate from the fitting seed.

| Group | Conditions | Cases |
| --- | --- | ---: |
| Noise | Three Table S1 circuits; per-component Gaussian noise coefficients 0, 3, 5, 10 and 20%; 50 frequencies, 0.01–10^6 Hz | 39 |
| Relaxation separation | Two RQ blocks, characteristic-frequency ratios 100, 10, 3 and 1.3; no noise or 3% noise; 81 frequencies | 16 |
| Frequency restriction | Paired subsets of the original 3%-noise spectra: f >= 1 Hz, f <= 1000 Hz, or both criteria | 27 |
| Outside-library topology | RQ plus a Gerischer G element, absent from the generated candidate sets; 0, 3 and 10% noise | 7 |

RQ denotes a resistor parallel to a CPE. Nonzero noise levels use three fixed realizations. Noise deviates are scaled across noise levels within each model/repeat, and truncations preserve the corresponding original noisy points.

## Reported outcomes and interpretation

`TABLE_S9.md` provides the four-group manuscript summary; `DETAILED_RECOVERY_COUNTS.md` gives counts for each individual condition. First-ranked generating-topology recovery was 11/39 in the noise series, 0/16 in the controlled relaxation-separation series and 7/27 in the frequency-restriction series. The generating topology was admitted in all 82 supported-topology cases; one generating-circuit fit failed. Outside-library recovery is not applicable because the generating topology was absent. All seven such cases returned a single-RQ surrogate.

These results describe the fixed tested snapshot and the stated controlled scenarios. The scenarios were not sampled to estimate a general experimental identification-success probability. Selecting the exact generating topology, fitting a specified circuit, and establishing a unique physical model are different outcomes.

Two implementation behaviors are documented in `IMPLEMENTATION_NOTES.md`:

1. Morphology categories precede information criteria and residual errors in the final lexicographic ranking. For the noise-free, frequency-ratio-100 example, the two-RQ candidate has MRE approximately 5.35e-10% but ranks third, while the selected single-RQ approximation has MRE 13.604%. The source and raw outputs are retained unchanged.
2. The adjusted-AICc confidence ordering and the final ranking have different leaders in 36/89 cases. Five of seven outside-library cases receive a `preferred` library-confidence summary. This label does not establish library completeness or necessarily describe confidence in the final selected circuit.

In the recorded NumPy 2.3.5 / impedance.py 1.7.1 environment, native Lin-KK diagnostics fail with `name 'np' is not defined`; the package traceback is in `LIN_KK_RUNTIME_DIAGNOSIS.txt`. The failure is preserved in every case and was not counted as a pass. Lin-KK output does not enter the tested worker's candidate construction, fitting or ranking. No Lin-KK performance claim is made from this assessment.

## Directory contents

- `input_cases.json`: all clean/noisy input spectra, frequencies, generating coefficients and noise seeds.
- `native_outputs/<case_id>/`: complete ranked candidate JSON, native ranking CSV, native selection audit and execution log for every case.
- `case_summary.csv`, `summary_results.json`: all case outcomes and group summaries.
- `source_snapshots/`: exact tested `eis_auto.py`, `eis_physics.py` and `auto_library.py` files.
- `source_provenance.json`: hashes and sizes of the tested source files.
- `protocol.json`, `execution_manifest.json`: conditions, executed case list and numerical environment.
- `generate_cases.py`: independent analytical input generation.
- `run_native_screening.py`: execution adapter calling the original automatic GUI worker without opening a GUI.
- `check_generator_conventions.py`: numerical check of analytical element conventions.
- `summarize_results.py`: case summaries, condition-level tables and scientific plots.
- `Figure_S12.png/.pdf`: the additional screening figure.
- `Ranking_Diagnostic.png/.pdf`: the documented separated-relaxation example.
- `VERIFICATION.json`: verification of recorded fit metrics and original source integrity.
- `MANIFEST.json`: hashes of files in this distribution.

## Reproduction

The recorded environment used Python 3.12.14. Install the packages in `requirements.txt` and ensure that system Tkinter is available for importing the supplied GUI module. No Tk root or graphical display is opened. Optional AutoEIS and Schemdraw are not required for these tests.

Run from this directory:

```bash
python generate_cases.py
python check_generator_conventions.py
python run_native_screening.py --workers 3 --force
python summarize_results.py
```

If impedance.py is installed in an isolated target directory, pass `--dependency-path /absolute/path/to/dependencies` to the convention check and native execution commands. Without `--force`, existing per-case results are reused. Batch execution uses a task-local native configuration with auto-learning disabled. New floating-point results can differ slightly with platform or numerical-library changes; the original full outputs and environment record are provided for comparison.
