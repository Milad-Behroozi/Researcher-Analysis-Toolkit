"""Execute the supplied RAT GUI worker without opening a graphical window.

The source files in source_snapshots remain unchanged. Only display widgets
and message dialogs are replaced by recording/no-op callbacks. All numerical
screening, candidate construction, refinement and ranking are native code.
"""
from __future__ import annotations
import argparse
import concurrent.futures
import contextlib
import hashlib
import importlib.metadata
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import time
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parent
NATIVE = None


def configure_import(dependency_path=None):
    global NATIVE
    if NATIVE is not None:
        return NATIVE
    os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
    os.environ.setdefault('OMP_NUM_THREADS','1')
    if dependency_path:
        sys.path.insert(0,str(Path(dependency_path).resolve()))
    sys.path.insert(0,str(ROOT/'source_snapshots'))
    # Use RAT's real configuration mechanism to disable mutable learned models.
    appdata = ROOT/'isolated_appdata'/f'worker_{os.getpid()}'
    os.environ['LOCALAPPDATA'] = str(appdata)
    folder = appdata/'Researcher'
    folder.mkdir(parents=True,exist_ok=True)
    (folder/'config.json').write_text('{"auto_learning": false}\n')
    import matplotlib
    matplotlib.use('Agg')
    spec = importlib.util.spec_from_file_location('rat_native_auto',ROOT/'source_snapshots/eis_auto.py')
    NATIVE = importlib.util.module_from_spec(spec)
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(NATIVE)
    if NATIVE.is_auto_learning_enabled('Researcher'):
        raise RuntimeError('Isolated auto-learning configuration was not disabled')
    return NATIVE


class Widget:
    def __init__(self): self.messages=[]
    def config(self,**kwargs): self.messages.append(kwargs)
    def insert(self,*args): self.messages.append(args)
    def select(self,*args): pass


class HeadlessContext:
    def __init__(self,case,out):
        import numpy as np
        self.f=np.array(case['frequency_Hz'],float)
        self.Z=np.array(case['Z_real_ohm'])+1j*np.array(case['Z_imag_ohm'])
        self.Phase_raw=None  # Matches the GUI '<None>' phase-column setting.
        self.search_level='L3'
        self.search_allowed_elements={'R','C','CPE','W','L'}
        self.output_folder=str(out)
        self.status=Widget();self.progress=Widget();self.result_box=Widget()
        self.notebook=Widget();self.tab_circuits='circuits'
        self.analysis_running=True;self.chosen_circuit=None;self.all_results=[]
        self.errors=[]
    def after(self,delay,callback,*args): return callback(*args)
    def _ui_update(self,**kwargs): pass
    def _refresh_circuit_table(self): pass
    def _set_summary_text(self): pass
    def _mark_analysis_idle(self): self.analysis_running=False


def safe(value):
    import numpy as np
    if value is None or isinstance(value,(str,bool,int)): return value
    if isinstance(value,(float,np.floating)):
        return float(value) if np.isfinite(value) else None
    if isinstance(value,np.integer): return int(value)
    if isinstance(value,np.bool_): return bool(value)
    if isinstance(value,np.ndarray): return safe(value.tolist())
    if isinstance(value,dict): return {str(k):safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,set)): return [safe(v) for v in value]
    return str(value)


def serialize_result(row,f):
    result={k:safe(v) for k,v in row.items() if k!='model'}
    model=row.get('model')
    if model is not None:
        result['fitted_parameters']=safe(model.parameters_)
        result['approximate_parameter_SE']=safe(getattr(model,'conf_',None))
        try:
            names,units=model.get_param_names()
            result['parameter_names']=names;result['parameter_units']=units
            zfit=model.predict(f)
            result['fit_real_ohm']=zfit.real.tolist()
            result['fit_imag_ohm']=zfit.imag.tolist()
        except Exception as error:
            result['serialization_note']=str(error)
    return result


def run_case(case,dependency_path=None,force=False):
    import numpy as np
    from threadpoolctl import threadpool_limits
    module=configure_import(dependency_path)
    output=ROOT/'native_outputs'/case['id']
    output.mkdir(parents=True,exist_ok=True)
    destination=output/'case_result.json'
    if destination.exists() and not force:
        return json.loads(destination.read_text())
    context=HeadlessContext(case,output)
    module.messagebox.showerror=lambda title,message:context.errors.append({'title':title,'message':message})
    logs=io.StringIO();started=time.perf_counter()
    with threadpool_limits(limits=1),contextlib.redirect_stdout(logs),contextlib.redirect_stderr(logs):
        # This is the original method, not a reimplementation of its logic.
        module.CorvaEISApp._run_pipeline_worker(context)
    rows=context.all_results
    truth=case['generating_circuit']
    truth_row=next((r for r in rows if r['circuit']==truth),None)
    selected=next((r for r in rows if r['circuit']==context.chosen_circuit),None)
    eligible=[r for r in rows if r.get('status')=='OK' and not r.get('hard_reject',False)
              and np.isfinite(float(r.get('physics_adjusted_aicc',np.inf)))]
    aicc_leader=min(eligible,key=lambda r:r['physics_adjusted_aicc'])['circuit'] if eligible else None
    result={
        'id':case['id'],'family':case['family'],'model':case['model'],
        'noise_fraction':case['noise_fraction'],'repeat':case['repeat'],
        'N':len(case['frequency_Hz']),
        'frequency_range_Hz':[min(case['frequency_Hz']),max(case['frequency_Hz'])],
        'generating_circuit':truth,'true_parameters':case['true_parameters'],
        'true_peak_frequency_ratio':case.get('true_peak_frequency_ratio'),
        'window':case.get('window'),'parent_full_case':case.get('parent_full_case'),
        'software_version':module.SOFTWARE_VERSION,
        'physics_engine_version':module.PHYSICS_ENGINE_VERSION,
        'candidate_count':len(rows),'generating_circuit_present':truth_row is not None,
        'generating_circuit_rank':next((i for i,r in enumerate(rows,1) if r['circuit']==truth),None),
        'generating_circuit_fit_status':None if truth_row is None else truth_row['status'],
        'selected_circuit':context.chosen_circuit,
        'exact_topology_recovered':context.chosen_circuit==truth,
        'selected_result':None if selected is None else serialize_result(selected,context.f),
        'confidence_summary':safe(getattr(context,'selection_confidence',{})),
        'physics_adjusted_AICc_leader':aicc_leader,
        'features':safe(getattr(context,'physics_features',{})),
        'lin_kk':safe(getattr(context,'lin_kk_result',{})),
        'errors':context.errors,'elapsed_seconds':time.perf_counter()-started,
        'ranked_results':[serialize_result(r,context.f) for r in rows],
    }
    (output/'execution_log.txt').write_text(logs.getvalue())
    destination.write_text(json.dumps(safe(result),indent=2,allow_nan=False)+'\n')
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dependency-path')
    parser.add_argument('--workers',type=int,default=3)
    parser.add_argument('--case-ids',nargs='*')
    parser.add_argument('--force',action='store_true')
    args=parser.parse_args()
    # Restrict BLAS before process creation and NumPy imports in the children.
    os.environ['OPENBLAS_NUM_THREADS']='1';os.environ['OMP_NUM_THREADS']='1'
    cases=json.loads((ROOT/'input_cases.json').read_text())
    if args.case_ids:
        wanted=set(args.case_ids);cases=[c for c in cases if c['id'] in wanted]
        if len(cases)!=len(wanted):raise ValueError('Unknown case id requested')
    done=[];start=time.perf_counter()
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(run_case,c,args.dependency_path,args.force):c['id'] for c in cases}
        for future in concurrent.futures.as_completed(futures):
            r=future.result();done.append(r)
            print(json.dumps({'completed':len(done),'total':len(cases),'id':r['id'],
                              'true_rank':r['generating_circuit_rank'],'present':r['generating_circuit_present'],
                              'selected':r['selected_circuit'],
                              'MRE_percent':None if r['selected_result'] is None else 100*r['selected_result']['mean_rel_err'],
                              'confidence':r['confidence_summary'].get('selection_status'),
                              'errors':r['errors'],'seconds':round(r['elapsed_seconds'],2)}),flush=True)
    versions={name:importlib.metadata.version(name) for name in ('numpy','scipy','matplotlib','pandas')}
    try:
        if args.dependency_path:sys.path.insert(0,args.dependency_path)
        versions['impedance']=importlib.metadata.version('impedance')
    except Exception:pass
    manifest={'executed_cases':[c['id'] for c in cases],'source_hashes':json.loads((ROOT/'source_provenance.json').read_text()),
              'environment':versions,'python':sys.version,'elapsed_seconds':time.perf_counter()-start,
              'search_level':'L3','auto_learning':False,'allowed_elements':['R','C','CPE','W','L']}
    name='execution_manifest.json' if not args.case_ids else 'smoke_execution_manifest.json'
    (ROOT/name).write_text(json.dumps(manifest,indent=2)+'\n')


if __name__=='__main__':main()
