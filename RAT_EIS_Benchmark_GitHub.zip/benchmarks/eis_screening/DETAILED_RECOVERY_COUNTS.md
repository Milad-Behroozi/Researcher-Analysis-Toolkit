# Detailed condition-level recovery counts

Values in panels (a–c) are the number of cases in which the generating topology was selected first, divided by the number tested. A generating topology excluded from the data-dependent candidate list is counted as no recovery. RQ denotes R parallel to CPE. These are end-to-end selection results, not fixed-circuit fitting accuracy.

## (a) Added Gaussian noise

| Noise coefficient, eta (%) | Single RQ | Two RQ | RQ + W |
| --- | --- | --- | --- |
| 0 | 1/1 | 0/1 | 1/1 |
| 3 | 3/3 | 0/3 | 2/3 |
| 5 | 3/3 | 0/3 | 1/3 |
| 10 | 0/3 | 0/3 | 0/3 |
| 20 | 0/3 | 0/3 | 0/3 |

Noise is the standard deviation of each real/imaginary perturbation, scaled by the noise-free impedance modulus; it is not the resulting complex MRE. Full spectra contain 50 points from 0.01 to 10^6 Hz. The two-RQ coefficients here are those in Table S1 and give strongly overlapping individual characteristic frequencies (approximately 539 and 707 Hz).

## (b) Controlled overlap of two RQ relaxations

| Characteristic-frequency ratio, f1/f2 | No added noise | eta = 3% |
| --- | --- | --- |
| 100 | 0/1 | 0/3 |
| 10 | 0/1 | 0/3 |
| 3 | 0/1 | 0/3 |
| 1.3 | 0/1 | 0/3 |

Here R0 = 10 ohm, R1 = R2 = 100 ohm and n1 = n2 = 0.85; f1 = 1000 Hz and Qj = 1/[Rj(2*pi*fj)^nj]. Each spectrum contains 81 logarithmic frequency points from 0.01 to 10^6 Hz.

## (c) Frequency-window restriction at eta = 3%

| Frequency-window rule | Single RQ | Two RQ | RQ + W |
| --- | --- | --- | --- |
| Full: 0.01–10^6 Hz | 3/3 | 0/3 | 2/3 |
| Retain f >= 1 Hz | 2/3 | 0/3 | 0/3 |
| Retain f <= 1000 Hz | 2/3 | 0/3 | 1/3 |
| Retain 1 <= f <= 1000 Hz | 1/3 | 0/3 | 1/3 |

Truncations retain exactly the corresponding original noisy data points; no interpolation, resampling or new noise is introduced. The retained point count and actual endpoint frequencies for every case are supplied in case_summary.csv.

## (d) Generating topology outside the candidate library

| eta (%) | Cases | Generating topology admitted | Selected MRE range (%) | Cases with structured residuals | Native confidence-summary labels |
| --- | --- | --- | --- | --- | --- |
| 0 | 1 | 0/1 | 2.602 | 1/1 | preferred: 1 |
| 3 | 3 | 0/3 | 4.410–4.646 | 2/3 | preferred: 3 |
| 10 | 3 | 0/3 | 11.428–12.748 | 0/3 | ambiguous: 1, preferred: 1, moderate-confidence: 1 |

The generating circuit is R0-p(R1,CPE1)-G1, with the single-RQ coefficients from Table S1 and ZG = RG/sqrt(1+j*2*pi*f*tG), RG = 30 ohm and tG = 0.01 s. No G-containing candidate is constructed at the tested search level. Topology recovery is therefore not applicable for this panel. A structured-residual case has the native residual_structure_rank > 0 (absolute lag-one residual correlation >= 0.35). The confidence summary compares eligible library candidates by adjusted AICc; it does not test library completeness. Its leading candidate can differ from the final lexicographically ranked selection.

All 89 cases were generated outside RAT using analytical NumPy equations and tested through the supplied, unmodified RAT 1.3.0-physics-preview automatic worker (physics engine 2.0.0), search level L3, default native seed 20260821 and auto-learning disabled. Three fixed noise realizations were used at each nonzero noise level. The same deviates were scaled across noise levels within each model/repeat. Optional Level 5/AutoEIS was not evaluated. All cases and candidate results, including failures to recover the generating circuit, are retained.
