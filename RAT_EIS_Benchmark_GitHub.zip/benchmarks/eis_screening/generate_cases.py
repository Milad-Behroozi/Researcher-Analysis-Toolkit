"""Independent analytical EIS generator for the predeclared screening suite.

Imports no RAT or impedance.py routines. Writes JSON input data and protocol.
"""
from pathlib import Path
import json
import numpy as np

ROOT = Path(__file__).resolve().parent
BASE_SEED = 20261019


def rq(f, resistance, q, exponent):
    return 1.0/(1.0/resistance + q*(2j*np.pi*f)**exponent)


def spectrum(model, p, f):
    z = p['R0'] + rq(f, p['R1'], p['Q1'], p['n1'])
    if model == 'double_rq':
        z = z + rq(f, p['R2'], p['Q2'], p['n2'])
    elif model == 'rq_w':
        z = z + p['AW']*(1-1j)/np.sqrt(2*np.pi*f)
    elif model == 'rq_g':
        z = z + p['RG']/np.sqrt(1+2j*np.pi*f*p['tG'])
    return z


def case(identifier, family, model, p, f, eta, seed, **extra):
    clean = spectrum(model, p, f)
    rng = np.random.default_rng(seed)
    epsilon_real = rng.standard_normal(len(f))
    epsilon_imag = rng.standard_normal(len(f))
    noisy = clean + eta*abs(clean)*(epsilon_real+1j*epsilon_imag)
    true_circuit = {'single_rq':'R0-p(R1,CPE1)',
                    'double_rq':'R0-p(R1,CPE1)-p(R2,CPE2)',
                    'rq_w':'R0-p(R1,CPE1)-W1',
                    'rq_g':'R0-p(R1,CPE1)-G1'}[model]
    return {'id': identifier, 'family': family, 'model': model,
            'generating_circuit': true_circuit, 'true_parameters': dict(p),
            'noise_fraction': eta, 'noise_seed': seed,
            'frequency_Hz': f.tolist(), 'Z_real_ohm': noisy.real.tolist(),
            'Z_imag_ohm': noisy.imag.tolist(),
            'Z_clean_real_ohm': clean.real.tolist(),
            'Z_clean_imag_ohm': clean.imag.tolist(), **extra}


def main():
    # Original manuscript frequency grid and generating coefficients.
    f = np.logspace(6, -2, 50)
    single = {'R0':10.0,'R1':10.0,'Q1':1e-4,'n1':.85}
    double = {**single,'R2':15.0,'Q2':1e-3,'n2':.5}
    diffusion = {**single,'AW':10.0}
    specifications = [('single_rq',single),('double_rq',double),('rq_w',diffusion)]
    cases = []
    full_noisy = {}
    for i,(model,p) in enumerate(specifications):
        for eta in (0.,.03,.05,.10,.20):
            for repeat in range(1 if eta == 0 else 3):
                seed = BASE_SEED+100*i+repeat
                ident = f'noise_{model}_{round(eta*100):02d}_r{repeat}'
                c = case(ident,'noise',model,p,f,eta,seed,repeat=repeat)
                cases.append(c)
                if eta == .03:
                    full_noisy[(model,repeat)] = c
    # Controlled relaxation separation: equal R and n; only Q2 changes.
    overlap_f = np.logspace(6,-2,81)
    for ratio in (100.,10.,3.,1.3):
        p = {'R0':10.,'R1':100.,'n1':.85,'R2':100.,'n2':.85}
        p['Q1'] = 1/(p['R1']*(2*np.pi*1000.)**p['n1'])
        p['Q2'] = 1/(p['R2']*(2*np.pi*(1000./ratio))**p['n2'])
        for eta in (0.,.03):
            for repeat in range(1 if eta == 0 else 3):
                ident = f'overlap_ratio{ratio:g}_{round(eta*100):02d}_r{repeat}'
                cases.append(case(ident,'overlap','double_rq',p,overlap_f,
                                  eta,BASE_SEED+1000+repeat,repeat=repeat,
                                  true_peak_frequency_ratio=ratio,
                                  true_peak_frequencies_Hz=[1000.,1000./ratio]))
    # Paired subsets of exactly the same noisy full-spectrum realizations.
    for (model,repeat),parent in full_noisy.items():
        fs = np.array(parent['frequency_Hz'])
        masks = {'without_low':fs>=1., 'without_high':fs<=1e3,
                 'central_window':(fs>=1.)&(fs<=1e3)}
        for window,mask in masks.items():
            child = dict(parent)
            child.update({'id':f'truncated_{model}_{window}_r{repeat}',
                          'family':'truncation','window':window,
                          'parent_full_case':parent['id']})
            for key in ('frequency_Hz','Z_real_ohm','Z_imag_ohm',
                        'Z_clean_real_ohm','Z_clean_imag_ohm'):
                child[key] = np.array(parent[key])[mask].tolist()
            cases.append(child)
    # Gerischer element G is absent from the supplied guided candidate builder.
    held_out = {**single,'RG':30.,'tG':.01}
    for eta in (0.,.03,.10):
        for repeat in range(1 if eta == 0 else 3):
            ident = f'out_of_library_G_{round(eta*100):02d}_r{repeat}'
            cases.append(case(ident,'out_of_library','rq_g',held_out,f,eta,
                              BASE_SEED+2000+repeat,repeat=repeat))
    protocol = {
        'suite_version':'1.0','case_count':len(cases),'source':'Independent analytical NumPy equations',
        'search_level':'L3','allowed_elements':['R','C','CPE','W','L'],
        'auto_learning':False,'AutoEIS_Level5':False,
        'noise_equation':'Znoisy = Zclean + eta*abs(Zclean)*(epsilon_real + j*epsilon_imag)',
        'noise_distribution':'Independent standard normal real/imaginary deviates',
        'repeats':'One realization at zero noise; three fixed noise seeds at nonzero noise',
        'paired_noise':'The same random deviates are scaled across noise levels within each model/repeat; truncations subset the 3% full spectra.',
        'primary_outcome':'Exact generating-circuit top-rank recovery in the native end-to-end workflow',
        'candidate_presence':'Record whether the generating topology is admitted to the data-dependent candidate list; failed admission counts as no recovery for supported-topology cases.',
        'out_of_library':'G is not constructed by the provided guided builder; rank recovery is not applicable for this family. Retain returned surrogate and native diagnostics.',
        'software_changes':'None; use the unmodified GUI pipeline worker with non-graphical display callbacks.',
    }
    (ROOT/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
    (ROOT/'input_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
    counts = {family:sum(c['family']==family for c in cases)
              for family in sorted(set(c['family'] for c in cases))}
    print(json.dumps({'cases':len(cases),'families':counts}))


if __name__ == '__main__':
    main()
